import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { spawn } from 'node:child_process';
import { fileURLToPath } from 'node:url';
import { once } from 'node:events';
import { score, reveal, publicCar, validateCar } from '../domain.mjs';

test('puan yüzdesel sapmayı izler, negatif olmaz ve eksik tahmini ödüllendirmez',()=>{
 assert.equal(score(1000000,1000000),1000);assert.equal(score(900000,1000000),900);assert.equal(score(1100000,1000000),900);assert.equal(score(3000000,1000000),0);assert.equal(score(null,1000000),0);
});
test('sonucu tekrar açmak puanı iki kez yazmaz',()=>{
 const r={phase:'guess',round:0,cars:[{price:100}],players:[{id:'p',name:'Test',total:0}],guesses:{p:90},history:[],revision:1};reveal(r);reveal(r);assert.equal(r.players[0].total,900);assert.equal(r.history.length,1);
});
test('oyuncu araç görünümü fiyat ve yönetici verilerini içermez',()=>{
 const c=publicCar({id:'x',brand:'Test',price:55,source:'secret',note:'secret',recorded:'today',status:'active',photos:[]});for(const k of ['price','source','note','recorded','id','status'])assert.equal(k in c,false);assert.equal(c.brand,'Test');
});
test('eksik araç taslak olabilir, eksik veya geçersiz fiyatlı araç yayınlanamaz',()=>{
 const base={brand:'Test',series:'Seri',status:'draft'};assert.equal(validateCar(base).status,'draft');assert.throws(()=>validateCar({...base,status:'active'}));assert.throws(()=>validateCar({...base,price:-1}));assert.throws(()=>validateCar({...base,photos:['javascript:alert(1)']}));
});

test('HTTP: iki oyuncu, yetkiler, gizli fiyat, sabit araç kaydı, yükleme, yeniden bağlanma ve süre bitişi',async t=>{
 const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
 const data=fs.mkdtempSync(path.join(os.tmpdir(),'garaj-arena-test-'));
 const port=19000+Math.floor(Math.random()*15000);let child;
 async function start(){child=spawn(process.execPath,['server.mjs'],{cwd:root,env:{...process.env,PORT:String(port),HOST:'127.0.0.1',ENABLE_DEMO:'true',DATA_DIR:data},stdio:['ignore','pipe','pipe']});await Promise.race([once(child.stdout,'data'),new Promise((_,reject)=>{const timer=setTimeout(()=>reject(Error('Server startup timeout')),8000);timer.unref();})]);}
 async function stop(){if(child&&child.exitCode===null){const exited=once(child,'exit');child.kill();await exited;}}
 t.after(async()=>{await stop();fs.rmSync(data,{recursive:true,force:true});});await start();
 const base=`http://127.0.0.1:${port}`;
 async function req(p,method='GET',body,token,expected=200){const response=await fetch(base+'/api'+p,{method,headers:{...(method==='POST'?{'Content-Type':'application/json'}:{}),...(token?{Authorization:'Bearer '+token}:{})},...(body?{body:JSON.stringify(body)}:{})});const result=await response.json();assert.equal(response.status,expected,JSON.stringify(result));return result;}
 await req('/cars','GET',null,null,401);
 const admin=await req('/setup','POST',{brand:'Test Garaj',password:'local-test-admin',hostPassword:'local-test-host'});
 await req('/setup','POST',{password:'local-test-admin',hostPassword:'local-test-host'},null,409);
 await req('/login','POST',{role:'admin',password:'incorrect'},null,401);
 const host=await req('/login','POST',{role:'host',password:'local-test-host'});
 await req('/cars','GET',null,host.token,401);
 const seeded=await req('/cars/seed','POST',{},admin.token);assert.equal(seeded.cars.length,3);assert.equal((await req('/cars/seed','POST',{},admin.token)).cars.length,3);
 const png='data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+j8foAAAAASUVORK5CYII=';
 await req('/upload','POST',{data:png},host.token,401);
 const uploaded=await req('/upload','POST',{data:png},admin.token);assert.equal((await fetch(base+uploaded.url)).status,200);
 await req('/upload','POST',{data:'data:image/png;base64,YWJj'},admin.token,400);
 const draft=await req('/cars/save','POST',{brand:'Test',series:'Yükleme',status:'draft',photos:[uploaded.url]},admin.token);assert.equal(draft.car.photos[0],uploaded.url);
 const chosen=seeded.cars[0];
 await req('/rooms','POST',{name:'Sunucu',rounds:4,duration:30},host.token,400);
 const created=await req('/rooms','POST',{name:'Sunucu',rounds:1,duration:10,filters:{brand:chosen.brand}},host.token);
 const friend=await req('/rooms/join','POST',{code:created.code,name:'Arkadaş'});
 await req('/rooms/join','POST',{code:created.code,name:'Arkadaş'},null,400);
 const rp='/rooms/'+created.code;
 await req(rp+'/settings','POST',{setting:'duration',delta:10},friend.token,403);
 const adjusted=await req(rp+'/settings','POST',{setting:'duration',delta:10},created.token);assert.equal(adjusted.duration,20);
 assert.equal((await req(rp,'GET',null,friend.token)).duration,20);
 await req(rp+'/settings','POST',{setting:'duration',delta:-10},created.token);
 await req(rp+'/settings','POST',{setting:'duration',delta:-10},created.token,400);
 await req(rp+'/settings','POST',{setting:'rounds',delta:1},created.token,400);
 await req(rp+'/start','POST',{},friend.token,403);
 await req(rp+'/lock','POST',{},created.token);
 await req('/rooms/join','POST',{code:created.code,name:'Üçüncü'},null,409);
 await req('/cars/save','POST',{...chosen,price:chosen.price+100000},admin.token);
 let view=await req(rp+'/start','POST',{},created.token);assert.equal(view.phase,'guess');assert.equal('price' in view.car,false);assert.equal(view.result,null);assert.equal('token' in view.players[0],false);
 await req(rp+'/settings','POST',{setting:'duration',delta:10},created.token,409);
 await req(rp+'/reveal','POST',{},created.token,400);
 await req(rp+'/guess','POST',{value:chosen.price,round:99},friend.token,409);
 await req(rp+'/guess','POST',{value:chosen.price,round:1},friend.token);
 await req(rp+'/guess','POST',{value:chosen.price+50000,round:1},friend.token,409);
 await req(rp+'/guess','POST',{value:chosen.price,round:1},friend.token,409);
 const locked=await req(rp,'GET',null,friend.token);assert.equal(locked.ownGuess,chosen.price);assert.equal(locked.players.filter(p=>p.submitted).length,1);assert.equal(locked.players.length,2);
 const hostView=await req(rp,'GET',null,created.token);assert.equal(hostView.ownGuess,null);assert.equal('guesses' in hostView,false);
 await req(rp+'/guess','POST',{value:Math.round(chosen.price*.9),round:1},created.token);
 const allSubmitted=await req(rp,'GET',null,created.token);assert.equal(allSubmitted.players.filter(p=>p.submitted).length,2);
 view=await req(rp+'/reveal','POST',{},created.token);assert.equal(view.result.price,chosen.price);assert.equal(view.players.find(p=>p.name==='Arkadaş').total,1000);
 await req(rp+'/reveal','POST',{},created.token,409);
 await req(rp+'/guess','POST',{value:123,round:1},friend.token,409);
 view=await req(rp+'/next','POST',{round:1},created.token);assert.equal(view.phase,'finished');assert.equal(view.history.length,1);
 await stop();await start();
 assert.equal((await req('/cars','GET',null,admin.token)).cars.length,4);
 assert.equal((await req(rp,'GET',null,friend.token)).phase,'finished');
 assert.equal((await fetch(base+'/samples.json')).status,404);assert.equal((await fetch(base+'/data/state.json')).status,404);
 const late=await req('/rooms','POST',{name:'Süre testi',rounds:1,duration:10,demo:true});const lp='/rooms/'+late.code;
 await req(lp+'/start','POST',{},late.token);await new Promise(resolve=>setTimeout(resolve,10300));
 await req(lp+'/guess','POST',{value:1,round:1},late.token,409);const ended=await req(lp,'GET',null,late.token);assert.equal(ended.phase,'result');assert.equal(ended.players[0].total,0);
});
