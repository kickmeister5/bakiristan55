import { DurableObject } from 'cloudflare:workers';
import { randomInt } from 'node:crypto';
import { AppError, requireThat, token, validateCar, eligibleCars, startRound, reveal, roomView } from '../domain.mjs';
import drafts from './vehicle-drafts.json';
async function passwordHash(value,salt=token()){const key=await crypto.subtle.importKey('raw',new TextEncoder().encode(value),'PBKDF2',false,['deriveBits']);const bits=await crypto.subtle.deriveBits({name:'PBKDF2',hash:'SHA-256',salt:new TextEncoder().encode(salt),iterations:100000},key,256);return salt+':'+Buffer.from(bits).toString('hex');}
async function passwordMatches(value,hash){if(typeof value!=='string'||!hash)return false;const actual=await passwordHash(value,hash.split(':')[0]);let diff=actual.length^hash.length;for(let i=0;i<actual.length;i++)diff|=actual.charCodeAt(i)^hash.charCodeAt(i);return diff===0;}
const security={'X-Content-Type-Options':'nosniff','Referrer-Policy':'same-origin','X-Frame-Options':'SAMEORIGIN','Content-Security-Policy':"default-src 'self'; img-src 'self' data: blob:; style-src 'self' 'unsafe-inline'; script-src 'self'; connect-src 'self'; frame-ancestors 'self'; base-uri 'self'; form-action 'self'"};
const json=(data,status=200)=>Response.json(data,{status,headers:{...security,'Cache-Control':'no-store'}});
const application={async fetch(request,env){const url=new URL(request.url);if(url.pathname.startsWith('/api/'))return env.GAME.get(env.GAME.idFromName('garaj-v1')).fetch(request);if(url.pathname.startsWith('/uploads/')){if(!/^\/uploads\/[a-f0-9]{32}\.(jpg|png|webp)$/.test(url.pathname))return new Response('Bulunamadı',{status:404});const obj=await env.PHOTOS.get(url.pathname.slice(9));if(!obj)return new Response('Bulunamadı',{status:404});return new Response(request.method==='HEAD'?null:obj.body,{headers:{...security,'Content-Type':obj.httpMetadata?.contentType||'image/jpeg','Cache-Control':'public,max-age=86400'}});}const response=await env.ASSETS.fetch(request);const out=new Response(response.body,response);for(const [k,v]of Object.entries(security))out.headers.set(k,v);return out;}};
export class GameStore extends DurableObject {
 constructor(ctx,env){super(ctx,env);this.limits=new Map();}
 async fetch(request){return this.ctx.blockConcurrencyWhile(async()=>{try{
 const env=this.env;
 let state=await this.ctx.storage.get('state');
 if(!state){requireThat(env.ADMIN_PASSWORD?.length>=10&&env.HOST_PASSWORD?.length>=8&&env.ADMIN_PASSWORD!==env.HOST_PASSWORD,'ADMIN_PASSWORD ve HOST_PASSWORD secret ayarlarını tamamlayın.',503);state={settings:{brand:'GARAJ ARENA'},adminHash:await passwordHash(env.ADMIN_PASSWORD),hostHash:await passwordHash(env.HOST_PASSWORD),cars:structuredClone(drafts),rooms:{},sessions:{}};await this.ctx.storage.put('state',state);}
 let dirty=false;function save(){dirty=true;}
 for(const [code,r]of Object.entries(state.rooms)){if(Date.now()-r.created>86400000){delete state.rooms[code];dirty=true;}}
 for(const [t,s]of Object.entries(state.sessions)){if(s.expires<Date.now()){delete state.sessions[t];dirty=true;}}
 const limits=this.limits;for(const [k,v]of limits)if(v.until<Date.now())limits.delete(k);
const sessions=state.sessions;
const limit=limits;
function rate(req, name, max=25, window=60000) {
  const key=name+':'+req.socket.remoteAddress; let l=limit.get(key);
  if(!l || Date.now()>l.until){l={count:0,until:Date.now()+window};limit.set(key,l);}
  requireThat(++l.count<=max,'Çok fazla deneme. Biraz bekleyip tekrar deneyin.',429);
}
function auth(req,role){const t=(req.headers.authorization||'').replace(/^Bearer /,''); const s=sessions[t]; requireThat(s && s.expires>Date.now() && (!role || s.role===role || s.role==='admin'),'Oturumunuz sona erdi. Tekrar giriş yapın.',401);return s;}
function newSession(role){const t=token();sessions[t]={role,expires:Date.now()+12*60*60*1000};save();return {token:t,role};}
const loopback = ip=>['127.0.0.1','::1','::ffff:127.0.0.1'].includes(ip);
function roomAuth(req,code){ const room=state.rooms[code]; requireThat(room,'Oda bulunamadı.',404);const t=(req.headers.authorization||'').replace(/^Bearer /,'');const p=room.players.find(p=>p.token===t);requireThat(p,'Bu odadaki oturumunuz bulunamadı.',403);p.lastSeen=Date.now();save();if(room.phase==='guess'&&Date.now()>=room.deadline){reveal(room);save();}return [room,p];}
function hostOnly(room,p){ requireThat(p.id===room.host,'Bu işlemi yalnızca oda sahibi yapabilir.',403); }
function player(name){name=String(name||'').trim();requireThat(name.length>=2&&name.length<=24,'Oyuncu adı 2–24 karakter olmalı.');return{id:token().slice(0,12),token:token(),name,total:0,lastSeen:Date.now()};}
function shuffled(cars){const a=structuredClone(cars);for(let i=a.length-1;i>0;i--){const j=randomInt(i+1);[a[i],a[j]]=[a[j],a[i]];}return a;}
const seed=()=>[];
async function body(req){const reader=req.raw.body?.getReader();if(!reader)return {};let size=0;const chunks=[];while(true){const {done,value}=await reader.read();if(done)break;size+=value.length;if(size>5*1024*1024){await reader.cancel();throw new AppError('Dosya çok büyük.',413);}chunks.push(value);}try{return JSON.parse(Buffer.concat(chunks).toString()||'{}');}catch{throw new AppError('İstek okunamadı.');}}
async function api(req,url){
 const route=url.pathname, method=req.method;
 if(method==='GET'&&route==='/api/meta')return{brand:state.settings.brand,configured:!!state.adminHash,canSetup:false,active:state.cars.filter(c=>c.status==='active').length,brands:[...new Set(state.cars.filter(c=>c.status==='active').map(c=>c.brand))].sort(),demoAvailable:false};
 if(method==='GET'&&route==='/api/session')return{role:auth(req).role};
 if(method==='GET'&&route==='/api/cars'){auth(req,'admin');return{cars:state.cars};}
 if(method==='GET'&&route==='/api/settings'){auth(req,'admin');return{brand:state.settings.brand};}
 const match=route.match(/^\/api\/rooms\/([A-Z2-9]{6})(?:\/(\w+))?$/);
 if(method==='GET'&&match){const[r,p]=roomAuth(req,match[1]);return roomView(r,p);}
 requireThat(method==='POST','Adres bulunamadı.',404);
 const b=await body(req);
 if(route==='/api/setup')throw new AppError('Kurulum Cloudflare secret ayarlarıyla yapılır.',403);
 if(route==='/api/login'){rate(req,'login',10);requireThat(state.adminHash,'Önce ilk kurulumu tamamlayın.',409);const role=b.role==='admin'?'admin':'host';requireThat(await passwordMatches(b.password,role==='admin'?state.adminHash:state.hostHash),'Parola doğru değil.',401);return newSession(role);}
 if(route==='/api/logout'){const t=(req.headers.authorization||'').replace(/^Bearer /,'');delete sessions[t];save();return{ok:true};}
 if(route==='/api/settings'){
   auth(req,'admin'); const brand=String(b.brand||'').trim();requireThat(brand.length>=2&&brand.length<=40,'Yayın adı 2–40 karakter olmalı.');
   if(b.hostPassword){requireThat(typeof b.hostPassword==='string'&&b.hostPassword.length>=8&&b.hostPassword.length<=128,'Yayıncı parolası 8–128 karakter olmalı.');state.hostHash=await passwordHash(b.hostPassword);for(const [t,s]of Object.entries(sessions))if(s.role==='host')delete sessions[t];}
   state.settings.brand=brand;save();return{ok:true};
 }
 if(route==='/api/cars/seed')throw new AppError('Demo kapalı.',404);
 if(route==='/api/cars/save'){
   auth(req,'admin');const prev=b.id?state.cars.find(c=>c.id===b.id):null;requireThat(!b.id||prev,'Araç bulunamadı.',404);const c=validateCar(b,prev);
   for(const p of c.photos)requireThat(p.startsWith('/uploads/') && await env.PHOTOS.head(p.slice(9)),'Fotoğraf dosyası bulunamadı. Tekrar yükleyin.');
   if(prev)state.cars[state.cars.indexOf(prev)]=c;else state.cars.push(c);save();return{car:c};
 }
 if(route==='/api/cars/archive'){auth(req,'admin');const c=state.cars.find(c=>c.id===b.id);requireThat(c,'Araç bulunamadı.',404);c.status='archived';save();return{ok:true};}
 if(route==='/api/upload'){
   auth(req,'admin');rate(req,'upload',80);requireThat(typeof b.data==='string','Fotoğraf seçin.');const m=b.data.match(/^data:image\/(jpeg|png|webp);base64,([A-Za-z0-9+/=]+)$/);requireThat(m,'Yalnızca JPG, PNG ve WebP fotoğraflar yüklenebilir.');
   const buf=Buffer.from(m[2],'base64');requireThat(buf.length<=3*1024*1024,'Fotoğraf en fazla 3 MB olabilir.');
   const valid=m[1]==='jpeg'?buf[0]===255&&buf[1]===216&&buf[2]===255:m[1]==='png'?buf.subarray(0,8).equals(Buffer.from([137,80,78,71,13,10,26,10])):buf.toString('ascii',0,4)==='RIFF'&&buf.toString('ascii',8,12)==='WEBP';
   requireThat(valid,'Fotoğraf dosyası geçersiz.');const name=token().slice(0,32)+'.'+(m[1]==='jpeg'?'jpg':m[1]);await env.PHOTOS.put(name,buf,{httpMetadata:{contentType:'image/'+m[1]}});return{url:'/uploads/'+name};
 }
 if(route==='/api/rooms'){
   rate(req,'create',12);const demo=false;requireThat(!b.demo,'Demo kapalı.',400);auth(req,'host');
   const p=player(b.name||'Yayıncı');const rounds=Number(b.rounds),duration=Number(b.duration);requireThat(Number.isInteger(rounds)&&rounds>=1&&rounds<=30,'Tur sayısı 1–30 arasında olmalı.');requireThat(Number.isInteger(duration)&&duration>=10&&duration<=180,'Süre 10–180 saniye arasında olmalı.');
   const filters=b.filters||{};const pool=eligibleCars(demo?seed():state.cars,filters);
   let code;do{code=Array.from({length:6},()=> 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789'[randomInt(32)]).join('');}while(state.rooms[code]);
   state.rooms[code]={code,host:p.id,players:[p],phase:'lobby',round:0,rounds,duration,filters,cars:shuffled(pool).slice(0,rounds),guesses:{},deadline:0,result:null,history:[],revision:1,locked:false,created:Date.now(),demo};save();return{code,token:p.token};
 }
 if(route==='/api/rooms/join'){
   rate(req,'join',30);const code=String(b.code||'').trim().toUpperCase(),r=state.rooms[code];requireThat(r,'Oda kodunu kontrol edin.',404);requireThat(r.phase==='lobby'&&!r.locked,'Bu oda yeni katılıma kapalı.',409);requireThat(r.players.length<16,'Oda dolu (en fazla 16 oyuncu).');const p=player(b.name);requireThat(!r.players.some(x=>x.name.toLocaleLowerCase('tr')===p.name.toLocaleLowerCase('tr')),'Bu kullanıcı adı odada kullanılıyor.');r.players.push(p);r.revision++;save();return{code,token:p.token};
 }
 if(match){
   const[r,p]=roomAuth(req,match[1]),action=match[2];
   if(action==='guess'){
     requireThat(r.phase==='guess','Bu tur için tahmin süresi bitti.',409);requireThat(Number(b.round)===r.round+1,'Tur değişti. Ekranı güncelleyin.',409);requireThat(r.guesses[p.id]===undefined,'İlk tahminin kilitlendi. Bu turda tekrar değiştiremezsin.',409);const value=Number(b.value);requireThat(Number.isSafeInteger(value)&&value>0&&value<=1000000000,'1–1 milyar TL arasında bir tahmin girin.');r.guesses[p.id]=value;r.revision++;
   }else if(action==='leave'){
     if(p.id===r.host){r.phase='closed';r.locked=true;}else{r.players=r.players.filter(x=>x.id!==p.id);delete r.guesses[p.id];}r.revision++;save();return{ok:true};
   }else{
     hostOnly(r,p);
     if(action==='start'){requireThat(r.phase==='lobby','Oyun zaten başladı.',409);const pool=eligibleCars(state.cars,r.filters);requireThat(pool.length>=r.rounds,'Oyuna başlamak için yeterli hazır araç yok.');r.cars=shuffled(pool).slice(0,r.rounds);r.locked=true;startRound(r);}
     else if(action==='settings'){
       requireThat(r.phase==='lobby','Ayarlar yalnızca lobide değiştirilebilir.',409);
       requireThat(['rounds','duration'].includes(b.setting),'Geçersiz ayar.');
       const step=b.setting==='rounds'?1:10;requireThat(b.delta===step||b.delta===-step,'Geçersiz değişim.');
       const value=r[b.setting]+b.delta;requireThat(value>=(b.setting==='rounds'?1:10)&&value<=(b.setting==='rounds'?30:180),'Ayar sınırına ulaşıldı.');
       if(b.setting==='rounds'){
         if(value>r.rounds){const pool=eligibleCars(r.demo?seed():state.cars,r.filters).filter(c=>!r.cars.some(x=>x.id===c.id));requireThat(pool.length>=value-r.rounds,'Tur eklemek için araç havuzunda yeterli araç yok.');r.cars.push(...shuffled(pool).slice(0,value-r.rounds));}
         else r.cars=r.cars.slice(0,value);
       }
       r[b.setting]=value;r.revision++;
     }
     else if(action==='lock'){requireThat(r.phase==='lobby','Oyun başladı.',409);r.locked=!r.locked;r.revision++;}
     else if(action==='kick'){requireThat(r.phase==='lobby','Oyuncu yalnızca lobide çıkarılabilir.');requireThat(b.id!==r.host,'Oda sahibi çıkarılamaz.');r.players=r.players.filter(x=>x.id!==b.id);r.revision++;}
     else if(action==='reveal'){requireThat(r.phase==='guess','Tahmin aşaması bitmiş.',409);requireThat(r.players.every(x=>r.guesses[x.id]!==undefined),'Sonucu erken açmak için herkes tahmin göndermeli.');reveal(r);}
     else if(action==='next'){requireThat(r.phase==='result','Önce turun bitmesini bekleyin.',409);requireThat(Number(b.round)===r.round+1,'Tur zaten değişti.',409);if(r.round+1>=r.rounds){r.phase='finished';r.revision++;}else{r.round++;startRound(r);}}
     else throw new AppError('İşlem bulunamadı.',404);
   }
   save();return roomView(r,p);
 }
 throw new AppError('Adres bulunamadı.',404);
}

 const url=new URL(request.url);if(request.method!=='GET'){requireThat((request.headers.get('content-type')||'').startsWith('application/json'),'JSON isteği gerekli.',415);const origin=request.headers.get('origin');if(origin)requireThat(new URL(origin).origin===url.origin,'Farklı kaynaktan gelen istek reddedildi.',403);}
 const req={raw:request,method:request.method,headers:Object.fromEntries(request.headers),socket:{remoteAddress:request.headers.get('CF-Connecting-IP')||'local'}};
 const result=await api(req,url);if(dirty)await this.ctx.storage.put('state',state);return json(result);
 }catch(e){return json({error:e.status?e.message:'Sunucu hatası.'},e.status||500);}});}
}

// Mount the app without taking over the existing website's root or API paths.
export default {async fetch(request,env){const url=new URL(request.url);const prefix='/garaj-arena';if(url.pathname===prefix){url.pathname+='/';return Response.redirect(url.toString(),308);}const mounted=url.pathname.startsWith(prefix+'/');if(mounted){url.pathname=url.pathname.slice(prefix.length);request=new Request(url,request);}const response=await application.fetch(request,env);if(mounted&&response.headers.has('Location')){const target=new URL(response.headers.get('Location'),url);if(target.origin===url.origin){target.pathname=prefix+target.pathname;const out=new Response(response.body,response);out.headers.set('Location',target.toString());return out;}}return response;}};
